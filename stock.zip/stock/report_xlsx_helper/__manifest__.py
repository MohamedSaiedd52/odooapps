

{
    "name": "Report xlsx helpers",
    "author": "Mohamed Saied",
    "category": "Reporting",
    "license": "AGPL-3",
    "depends": ["report_xlsx"],
    "development_status": "Mature",
    "installable": True,
}
